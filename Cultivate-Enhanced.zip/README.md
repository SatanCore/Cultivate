# Путь Бессмертного — Cultivate

Android-игра на Kotlin и Jetpack Compose.

## Открытие проекта
Откройте эту папку целиком в Android Studio. Корневые `settings.gradle.kts` и `build.gradle.kts` находятся рядом с папкой `app`.

## Сборка APK
В GitHub Actions запустите workflow **Build Android APK** (или отправьте commit в `main`/`master`). APK появится в артефактах workflow как `Cultivate-Game-APK`.

## Что включено в эту версию
- исходная игровая логика и пять основных вкладок;
- оригинальная иллюстрация главного героя, встроенная в экран персонажа;
- исправленная структура Android Studio проекта и GitHub Actions workflow.

Это ранняя игровая сборка: PvP между реальными игроками, серверная синхронизация, полноценная 3D-анимация и сетевые функции ещё не реализованы.
